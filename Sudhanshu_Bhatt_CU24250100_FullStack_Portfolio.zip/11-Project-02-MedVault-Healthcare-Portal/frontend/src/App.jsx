import React, { useState } from 'react';
import './App.css';

/**
 * MedVault - Enterprise Healthcare & Medical Records Portal
 * Author: Sudhanshu Bhatt (CUID: CU24250100 | Roll 63 | Section A)
 */
export default function App() {
  const [role, setRole] = useState('doctor'); // 'doctor' | 'patient' | 'admin'
  const [records, setRecords] = useState([
    { id: 1, patient: 'Sudhanshu Bhatt', cuid: 'CU24250100', department: 'General Medicine', title: 'Annual Health Check & Bloodwork Panel', type: 'PDF', date: '2026-10-12', size: '2.4 MB' },
    { id: 2, patient: 'Aarav Sharma', cuid: 'CU24250101', department: 'Ophthalmology', title: 'Vision Screening & Prescription Specs', type: 'PDF', date: '2026-10-10', size: '1.2 MB' },
    { id: 3, patient: 'Ananya Patel', cuid: 'CU24250102', department: 'Orthopedics', title: 'Sports Injury Physical Therapy Report', type: 'PDF', date: '2026-10-08', size: '3.1 MB' }
  ]);

  const [newTitle, setNewTitle] = useState('');
  const [newDept, setNewDept] = useState('General Medicine');
  const [patientName, setPatientName] = useState('Sudhanshu Bhatt');

  const handleUpload = (e) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    setRecords([
      {
        id: Date.now(),
        patient: patientName,
        cuid: 'CU24250100',
        department: newDept,
        title: newTitle.trim(),
        type: 'PDF',
        date: new Date().toISOString().split('T')[0],
        size: '1.8 MB'
      },
      ...records
    ]);
    setNewTitle('');
  };

  return (
    <div>
      <nav className="navbar">
        <div className="brand">
          <span>🏥 MedVault &bull; Campus Health &amp; Patient Portal</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <select
            value={role}
            onChange={(e) => setRole(e.target.value)}
            style={{ padding: '5px 10px', borderRadius: '4px', background: 'white', border: 'none', fontSize: '0.82rem', fontWeight: 'bold' }}
          >
            <option value="doctor">View as: Doctor (Staff Mode)</option>
            <option value="patient">View as: Patient (Sudhanshu)</option>
            <option value="admin">View as: Super Admin</option>
          </select>
          <div className="badge">
            Sudhanshu Bhatt &bull; CU24250100 &bull; Roll 63 (Sec A)
          </div>
        </div>
      </nav>

      <main className="container">
        {/* Metric Cards */}
        <div className="metrics-row">
          <div className="metric-box">
            <h3>2,840</h3>
            <p>Active Patient Records</p>
          </div>
          <div className="metric-box">
            <h3>42</h3>
            <p>Consultations Today</p>
          </div>
          <div className="metric-box">
            <h3>{records.length}</h3>
            <p>Verified Lab Reports</p>
          </div>
          <div className="metric-box">
            <h3 style={{ color: '#10b981' }}>1.3 ms</h3>
            <p>Indexed Query Speed (B-Tree)</p>
          </div>
        </div>

        {/* Medical Document Repository */}
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '18px' }}>
            <div>
              <h2 style={{ margin: 0, fontSize: '1.3rem' }}>📁 Certified Medical Records &amp; Prescriptions</h2>
              <p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '0.85rem' }}>
                Encrypted health documents with MIME validation and role-scoped permissions.
              </p>
            </div>
          </div>

          <div className="resource-grid">
            {records.map((rec) => (
              <div key={rec.id} className="resource-card">
                <div>
                  <span style={{ fontSize: '0.75rem', fontWeight: 'bold', color: '#0284c7' }}>
                    {rec.department} &bull; {rec.type}
                  </span>
                  <h4 style={{ margin: '6px 0 6px', fontSize: '1rem' }}>{rec.title}</h4>
                  <div style={{ fontSize: '0.8rem', color: '#475569', marginBottom: '4px' }}>
                    Patient: <strong>{rec.patient}</strong> (<code>{rec.cuid}</code>)
                  </div>
                  <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>
                    Date: {rec.date} &bull; Size: {rec.size}
                  </span>
                </div>
                <button
                  onClick={() => alert(`Downloading verified patient record: ${rec.title}\nPatient: ${rec.patient}`)}
                  className="btn"
                  style={{ marginTop: '16px', fontSize: '0.85rem', textAlign: 'center' }}
                >
                  Download Report ↓
                </button>
              </div>
            ))}
          </div>

          {/* Upload Form for Doctors and Admins */}
          {(role === 'doctor' || role === 'admin') && (
            <form onSubmit={handleUpload} style={{ marginTop: '24px', borderTop: '1px solid #e2e8f0', paddingTop: '18px' }}>
              <h4 style={{ margin: '0 0 10px' }}>Upload Certified Medical Lab Report / Prescription (Doctor RBAC)</h4>
              <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                <input
                  type="text"
                  placeholder="Patient Name (e.g., Sudhanshu Bhatt)..."
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  style={{ flex: 1, padding: '8px 12px', border: '1px solid #cbd5e1', borderRadius: '6px' }}
                  required
                />
                <input
                  type="text"
                  placeholder="Report Title (e.g., Blood Sugar & ECG Panel)..."
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  style={{ flex: 2, padding: '8px 12px', border: '1px solid #cbd5e1', borderRadius: '6px' }}
                  required
                />
                <select
                  value={newDept}
                  onChange={(e) => setNewDept(e.target.value)}
                  style={{ flex: 1, padding: '8px', border: '1px solid #cbd5e1', borderRadius: '6px' }}
                >
                  <option value="General Medicine">General Medicine</option>
                  <option value="Ophthalmology">Ophthalmology</option>
                  <option value="Orthopedics">Orthopedics</option>
                  <option value="Dental">Dental Care</option>
                </select>
                <button type="submit" className="btn">
                  + Upload Certified PDF
                </button>
              </div>
            </form>
          )}
        </div>
      </main>
    </div>
  );
}
