const express = require('express');
const router = express.Router();

router.get('/stats', (req, res) => {
  res.json({
    success: true,
    data: {
      totalStudentsEnrolled: 1420,
      activeEvents: 18,
      sharedStudyResources: 245,
      studentDetails: {
        name: 'Sudhanshu Bhatt',
        cuid: 'CU24250100',
        roll: 63,
        section: 'A'
      }
    }
  });
});

module.exports = router;
