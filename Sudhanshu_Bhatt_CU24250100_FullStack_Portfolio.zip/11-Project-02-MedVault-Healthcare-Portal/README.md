# Capstone Project 2: MedVault — Enterprise Healthcare & Patient Record Portal

**Student Name:** Sudhanshu Bhatt  
**CUID:** CU24250100  
**Roll Number:** 25  
**Section:** A  
**Course:** Full Stack Web Development (B.Tech CSE)  

---

## 1. Project Overview & Architecture
**MedVault** is a secure, HIPAA-conscious campus healthcare and medical record management portal. Built using the **MERN Stack** (MongoDB, Express, React, Node.js) with strict **Role-Based Access Control (RBAC)**, verified **Multer PDF file storage** for digital prescriptions/lab reports, and **MongoDB Compound B-Tree Index Optimization**.

### Key Architectural Features:
1. **Multi-Role RBAC Permissions Matrix:**
   - **Super Admin:** Manage medical staff, inspect clinic appointment throughput, audit access logs.
   - **Doctor / Medical Officer:** Review patient consultation histories, create medical prescriptions, upload certified lab reports (PDF/DOCX).
   - **Student / Patient:** Schedule clinic appointments, check doctor availability, download personal health records.
2. **Secure Document Management (Multer):**
   - Strictly validates MIME types (`application/pdf`, `image/jpeg`, `image/png`).
   - Caps upload size at 10MB to eliminate denial-of-service storage attacks.
   - Renames files using cryptographically random hashes to block path traversal vulnerabilities.
3. **Compound B-Tree Indexing Benchmark (`benchmark-indexing.js`):**
   - Benchmark script testing 10,000 synthetic patient consultations.
   - Proves compound index `{ department: 1, consultationDate: 1 }` cuts query latency from 118ms (collection scan) down to 1.3ms (B-Tree index scan).
4. **Standardized Postman Collection:**
   - Pre-configured API requests in `MedVault_API.postman_collection.json`.

---

## 2. RBAC Permissions Matrix

| Endpoint | Method | Public | Student / Patient | Doctor / Medical Officer | Super Admin |
| :--- | :---: | :---: | :---: | :---: | :---: |
| `/api/auth/register` & `/login` | `POST` | ✓ | ✓ | ✓ | ✓ |
| `/api/appointments` | `GET` | ✗ | ✓ (own) | ✓ (assigned) | ✓ (all) |
| `/api/appointments/book` | `POST` | ✗ | ✓ | ✗ | ✓ |
| `/api/records/upload` | `POST` | ✗ | ✗ | ✓ | ✓ |
| `/api/records/:id/download` | `GET` | ✗ | ✓ (own) | ✓ | ✓ |
| `/api/analytics/stats` | `GET` | ✗ | ✗ | ✗ | ✓ |

---

## 3. How to Run Locally

### Backend Setup:
```bash
cd 11-Project-02-MedVault-Healthcare-Portal/backend
npm install
npm start

# Run the 10,000 document compound indexing benchmark:
node src/benchmark-indexing.js
```

### Frontend Setup:
```bash
cd ../frontend
npm install
npm run dev
# Opens at http://localhost:3000 or http://localhost:5173
```

---

## 4. Viva Questions & Demonstration Talking Points

### Q1: Why is compound indexing critical in healthcare portals?
- A typical clinic query searches for appointments by department AND date (`{ department: 'Cardiology', date: { $gte: ISODate() } }`).
- Without an index, MongoDB scans every patient record in the database. A compound B-Tree index `{ department: 1, date: 1 }` enables the query planner to jump directly to matching leaf nodes in O(log N) time, speeding up execution by ~85x.

### Q2: What security measures protect patient documents in MedVault?
- Strict MIME-type filtering in Multer rejects executable files (.exe, .sh, .js).
- Files are assigned random UUID hashes on disk and served through authenticated Express middleware ensuring students can only access records mapped to their own CUID (`CU24250100`).
