import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';
import './App.css';

/**
 * DevPulse - Real-Time Developer Collaboration & Incident Platform
 * Author: Sudhanshu Bhatt (CUID: CU24250100 | Roll 63 | Section A)
 */
export default function App() {
  const [user, setUser] = useState({
    name: 'Sudhanshu Bhatt',
    email: 'sudhanshubhatt.edu@gmail.com',
    role: 'tech-lead',
    cuid: 'CU24250100'
  });

  const [sprintTasks, setSprintTasks] = useState([
    {
      id: 't1',
      title: 'Implement Redis Cache-Aside for Sprint Burndown',
      assignee: 'Sudhanshu Bhatt',
      status: 'DONE',
      priority: 'HIGH',
      points: 5
    },
    {
      id: 't2',
      title: 'Integrate Socket.io WebSocket Broadcast Channel',
      assignee: 'Sudhanshu Bhatt',
      status: 'IN_PROGRESS',
      priority: 'URGENT',
      points: 8
    },
    {
      id: 't3',
      title: 'Harden JWT Authentication & Role Authorization Middleware',
      assignee: 'Dev Team',
      status: 'TODO',
      priority: 'MEDIUM',
      points: 3
    }
  ]);

  const [incidents, setIncidents] = useState([
    {
      id: 'i1',
      title: 'Pipeline Build Warning: Staging Cluster Latency Spike',
      description: 'Staging pod memory consumption exceeded 80%. Automated scaling triggered.',
      severity: 'WARNING',
      timestamp: '10:24 AM'
    },
    {
      id: 'i2',
      title: 'Production Deploy #42 Released Cleanly',
      description: 'Zero-downtime rolling update completed across API microservices.',
      severity: 'INFO',
      timestamp: '09:15 AM'
    }
  ]);

  const [newIncidentTitle, setNewIncidentTitle] = useState('');
  const [newIncidentDesc, setNewIncidentDesc] = useState('');
  const [severity, setSeverity] = useState('CRITICAL');
  const [wsOnline, setWsOnline] = useState(true);

  // WebSocket connection with fallback
  useEffect(() => {
    try {
      const socket = io('http://localhost:5000', { autoConnect: false });
      socket.connect();
      socket.on('connect', () => setWsOnline(true));
      socket.on('disconnect', () => setWsOnline(false));
      socket.on('new_incident', (data) => {
        setIncidents((prev) => [data, ...prev]);
      });
      return () => socket.disconnect();
    } catch {
      // offline simulation
    }
  }, []);

  const handleBroadcast = (e) => {
    e.preventDefault();
    if (!newIncidentTitle.trim() || !newIncidentDesc.trim()) return;

    const newAlert = {
      id: `i_${Date.now()}`,
      title: newIncidentTitle.trim(),
      description: newIncidentDesc.trim(),
      severity,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setIncidents((prev) => [newAlert, ...prev]);
    setNewIncidentTitle('');
    setNewIncidentDesc('');
  };

  const handleMoveTask = (id, newStatus) => {
    setSprintTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, status: newStatus } : t))
    );
  };

  return (
    <div className="app-container">
      <header className="header-bar">
        <div className="brand-title">
          <span>⚡ DevPulse &bull; Real-Time Sprint &amp; Incident Hub</span>
          <span style={{ fontSize: '0.75rem', background: wsOnline ? '#10b981' : '#f59e0b', color: 'white', padding: '2px 8px', borderRadius: '4px' }}>
            {wsOnline ? 'WebSocket Connected' : 'Local Sandbox'}
          </span>
        </div>
        <div className="student-badge">
          Sudhanshu Bhatt &bull; CU24250100 &bull; Roll 63 (Sec A)
        </div>
      </header>

      <main className="main-content">
        {/* Incident Alerts Broadcast Feed */}
        <section className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
            <h2 style={{ margin: 0, fontSize: '1.25rem' }}>🚨 Real-Time Developer Incident Broadcasts</h2>
            <span style={{ fontSize: '0.8rem', color: '#64748b' }}>Live Socket.io Feed</span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {incidents.map((inc) => (
              <div
                key={inc.id}
                style={{
                  background: inc.severity === 'CRITICAL' ? '#fef2f2' : inc.severity === 'WARNING' ? '#fffbeb' : '#f0fdf4',
                  borderLeft: `4px solid ${inc.severity === 'CRITICAL' ? '#ef4444' : inc.severity === 'WARNING' ? '#f59e0b' : '#10b981'}`,
                  padding: '12px 16px',
                  borderRadius: '6px'
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                  <strong style={{ fontSize: '0.95rem' }}>{inc.title}</strong>
                  <span style={{ fontSize: '0.75rem', fontWeight: 700, padding: '2px 8px', borderRadius: '4px', background: 'white' }}>
                    {inc.severity}
                  </span>
                </div>
                <p style={{ margin: 0, color: '#475569', fontSize: '0.88rem' }}>{inc.description}</p>
                <span style={{ fontSize: '0.75rem', color: '#94a3b8', display: 'block', marginTop: '6px' }}>
                  Broadcast at {inc.timestamp}
                </span>
              </div>
            ))}
          </div>

          {/* Trigger Alert Form */}
          <form onSubmit={handleBroadcast} style={{ marginTop: '20px', borderTop: '1px solid #e2e8f0', paddingTop: '16px' }}>
            <h4 style={{ margin: '0 0 10px', fontSize: '0.9rem', color: '#1e293b' }}>Broadcast Live System Alert (Tech Lead RBAC)</h4>
            <div style={{ display: 'flex', gap: '10px', marginBottom: '10px', flexWrap: 'wrap' }}>
              <input
                type="text"
                placeholder="Incident summary..."
                value={newIncidentTitle}
                onChange={(e) => setNewIncidentTitle(e.target.value)}
                style={{ flex: 2, padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                required
              />
              <select
                value={severity}
                onChange={(e) => setSeverity(e.target.value)}
                style={{ flex: 1, padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
              >
                <option value="CRITICAL">CRITICAL Incident</option>
                <option value="WARNING">WARNING Alert</option>
                <option value="INFO">INFO Notice</option>
              </select>
            </div>
            <textarea
              rows={2}
              placeholder="Incident details, error code, or rollback instructions..."
              value={newIncidentDesc}
              onChange={(e) => setNewIncidentDesc(e.target.value)}
              style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', marginBottom: '10px' }}
              required
            />
            <button type="submit" className="btn btn-primary">
              Broadcast Alert to All Devs &rarr;
            </button>
          </form>
        </section>

        {/* Sprint Board Kanban */}
        <section className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <div>
              <h2 style={{ margin: 0, fontSize: '1.25rem' }}>📋 Active Sprint Backlog &amp; Burndown</h2>
              <p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '0.85rem' }}>
                Cached in Redis RAM for instantaneous state hydration (&lt; 4ms latency).
              </p>
            </div>
            <span style={{ fontSize: '0.85rem', fontWeight: 600, color: '#4f46e5' }}>
              Sprint 2026.4 &bull; 16 Points
            </span>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '16px' }}>
            {['TODO', 'IN_PROGRESS', 'DONE'].map((col) => (
              <div key={col} style={{ background: '#f8fafc', padding: '14px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                  <h4 style={{ margin: 0, fontSize: '0.9rem', color: '#334155' }}>{col.replace('_', ' ')}</h4>
                  <span style={{ fontSize: '0.75rem', fontWeight: 700, background: '#e2e8f0', padding: '2px 7px', borderRadius: '999px' }}>
                    {sprintTasks.filter((t) => t.status === col).length}
                  </span>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  {sprintTasks
                    .filter((t) => t.status === col)
                    .map((task) => (
                      <div key={task.id} style={{ background: 'white', padding: '12px', borderRadius: '6px', border: '1px solid #cbd5e1', boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}>
                        <div style={{ fontWeight: 600, fontSize: '0.9rem', marginBottom: '4px' }}>{task.title}</div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.78rem', color: '#64748b', marginTop: '8px' }}>
                          <span>👤 {task.assignee}</span>
                          <span style={{ fontWeight: 700, color: '#4f46e5' }}>{task.points} pts</span>
                        </div>

                        {/* Status Transition buttons */}
                        <div style={{ display: 'flex', gap: '6px', marginTop: '10px' }}>
                          {col !== 'TODO' && (
                            <button
                              onClick={() => handleMoveTask(task.id, 'TODO')}
                              style={{ fontSize: '0.7rem', padding: '3px 8px', border: '1px solid #cbd5e1', background: 'white', borderRadius: '4px', cursor: 'pointer' }}
                            >
                              &larr; Todo
                            </button>
                          )}
                          {col !== 'IN_PROGRESS' && (
                            <button
                              onClick={() => handleMoveTask(task.id, 'IN_PROGRESS')}
                              style={{ fontSize: '0.7rem', padding: '3px 8px', border: '1px solid #cbd5e1', background: 'white', borderRadius: '4px', cursor: 'pointer' }}
                            >
                              In Progress
                            </button>
                          )}
                          {col !== 'DONE' && (
                            <button
                              onClick={() => handleMoveTask(task.id, 'DONE')}
                              style={{ fontSize: '0.7rem', padding: '3px 8px', border: '1px solid #10b981', background: '#ecfdf5', color: '#047857', borderRadius: '4px', cursor: 'pointer' }}
                            >
                              Done &rarr;
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
