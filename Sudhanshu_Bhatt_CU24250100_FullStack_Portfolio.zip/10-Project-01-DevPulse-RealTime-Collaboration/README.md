# Capstone Project 1: DevPulse — Real-Time Agile Sprint & Developer Incident Hub

**Student Name:** Sudhanshu Bhatt  
**CUID:** CU24250100  
**Roll Number:** 25  
**Section:** A  
**Course:** Full Stack Web Development (B.Tech CSE)  

---

## 1. Project Overview & Architecture
**DevPulse** is a high-performance, real-time developer workspace and incident response platform. Built on the **MERN Stack** (MongoDB, Express, React, Node.js) augmented with **Socket.io WebSockets** and a **Redis In-Memory Cache-Aside Layer**.

### Core Capabilities:
1. **Real-Time WebSocket Incident & Deploy Broadcasts:**
   - When a DevOps engineer triggers a pipeline build or service incident alert, the event is instantaneously broadcast to all connected developer client sockets via Socket.io.
2. **Redis In-Memory Sprint Cache-Aside:**
   - Sprint burndown charts, backlog metrics, and active task states are cached in Redis (`sprint:active:metrics`). Query read latency drops from ~90ms (disk queries) to sub-4ms (Redis RAM).
3. **Role-Based Developer Controls:**
   - **Lead / Admin:** Create sprints, broadcast system incidents, modify task assignments.
   - **Developer / Member:** Claim backlog tickets, transition tasks (Todo -> In-Progress -> Done), and receive instant notifications.
4. **Resilient Offline Fallback:**
   - Built-in graceful memory fallback: if Redis or MongoDB is offline during an evaluation, DevPulse runs smoothly in standalone memory mode without crashing.
5. **Multi-Service Docker Containerization:**
   - Complete `docker-compose.yml` orchestrating API gateway, React client, Redis server, and MongoDB container.

---

## 2. System Architecture
```
[ React SPA Client (Port 3000 / Port 5173) ]
           │                                 ▲
           │ HTTP REST                       │ WebSockets (Socket.io)
           ▼                                 │
   [ Express.js API Gateway (Port 5000) ] ───┘
     ├── Rate Limiter & JWT Auth
     ├── Redis Cache-Aside Layer <──> [ Redis In-Memory Engine (Port 6379) ]
     └── Mongoose ODM <──────────────> [ MongoDB Server (Port 27017) ]
```

---

## 3. How to Run Locally

### Option A: Using Docker Compose (Recommended)
```bash
cd 10-Project-01-DevPulse-RealTime-Collaboration
docker compose up --build
```
- Frontend UI: `http://localhost:3000`
- Backend API: `http://localhost:5000`

### Option B: Local Node.js Development
```bash
# 1. Start DevPulse Backend:
cd 10-Project-01-DevPulse-RealTime-Collaboration/backend
npm install
npm start

# 2. Start DevPulse Frontend:
cd ../frontend
npm install
npm run dev
# Opens at http://localhost:3000 or http://localhost:5173
```

---

## 4. Viva Questions & Demonstration Talking Points

### Q1: Why use WebSockets over HTTP Polling in DevPulse?
- HTTP polling repeatedly queries the server every few seconds, generating high overhead and network traffic.
- WebSockets maintain a persistent, bidirectional TCP connection. When a deploy incident or task status change occurs, the server pushes the JSON payload to all connected developers with sub-10ms latency and minimal overhead.

### Q2: How does the Redis Cache-Aside pattern work in DevPulse?
- When `GET /api/sprints/active` is called:
  1. DevPulse checks Redis key `sprint:active:metrics`.
  2. If found (Cache Hit), cached data is returned instantly (~4ms).
  3. If missing (Cache Miss), MongoDB is queried, the response is stored in Redis with a 120-second TTL, and returned to the client.
  4. On task creation or transition, `redisClient.del('sprint:active:metrics')` invalidates the stale cache.
