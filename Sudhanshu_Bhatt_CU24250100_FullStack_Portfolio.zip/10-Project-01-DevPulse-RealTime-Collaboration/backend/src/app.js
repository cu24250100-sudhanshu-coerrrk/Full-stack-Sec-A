const express = require('express');
const cors = require('cors');

const authRoutes = require('./routes/auth.routes');
const eventRoutes = require('./routes/event.routes');
const announcementRoutes = require('./routes/announcement.routes');

const app = express();

app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/sprints', eventRoutes);
app.use('/api/incidents', announcementRoutes);

// Health Endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'online',
    project: 'DevPulse - Real-Time Developer Collaboration & Sprint Hub',
    student: {
      name: 'Sudhanshu Bhatt',
      cuid: 'CU24250100',
      roll: 25,
      section: 'A'
    }
  });
});

module.exports = app;
